import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Loader2 } from 'lucide-react';
import axios from 'axios';
import type { Message, ChatState } from './types';

function App() {
  const [state, setState] = useState<ChatState>({
    messages: [],
    isLoading: false,
    error: null
  });
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [state.messages]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || state.isLoading) return;

    const userMessage: Message = { role: 'user', content: input };
    setState(prev => ({
      ...prev,
      messages: [...prev.messages, userMessage],
      isLoading: true,
      error: null
    }));
    setInput('');

    try {
      const response = await axios.post('https://openrouter.ai/api/v1/chat/completions', {
        model: "mistralai/ministral-8b",
        messages: [...state.messages, userMessage]
      }, {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${import.meta.env.VITE_OPENROUTER_API_KEY}`
        }
      });

      const assistantMessage: Message = {
        role: 'assistant',
        content: response.data.choices[0].message.content
      };

      setState(prev => ({
        ...prev,
        messages: [...prev.messages, assistantMessage],
        isLoading: false
      }));
    } catch (error) {
      setState(prev => ({
        ...prev,
        isLoading: false,
        error: 'Failed to get response. Please try again.'
      }));
    }
  };

  return (
    <div className="min-h-screen bg-[#120F2D] flex flex-col">
      <header className="bg-[#120F2D] shadow-lg border-b border-[#2A3439]">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="flex items-center space-x-2">
            <Bot className="w-8 h-8 text-[#C0C0C0]" />
            <h1 className="text-2xl font-bold text-[#C0C0C0]">AI Chat Assistant</h1>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-4xl w-full mx-auto p-4 flex flex-col">
        <div className="flex-1 bg-[#120F2D] rounded-lg shadow-xl border border-[#2A3439] p-4 mb-4 overflow-y-auto max-h-[calc(100vh-16rem)]">
          {state.messages.map((message, index) => (
            <div
              key={index}
              className={`mb-4 flex ${
                message.role === 'user' ? 'justify-end' : 'justify-start'
              }`}
            >
              <div
                className={`flex items-start space-x-2 max-w-[80%] ${
                  message.role === 'user'
                    ? 'flex-row-reverse space-x-reverse'
                    : 'flex-row'
                }`}
              >
                <div
                  className={`p-3 rounded-lg ${
                    message.role === 'user'
                      ? 'bg-[#2A3439] text-[#FFFFFF]'
                      : 'bg-[#1B1B1B] text-[#FFFFFF]'
                  }`}
                >
                  <div className="flex items-center space-x-2 mb-1">
                    {message.role === 'user' ? (
                      <User className="w-4 h-4 text-[#C0C0C0]" />
                    ) : (
                      <Bot className="w-4 h-4 text-[#C0C0C0]" />
                    )}
                    <span className="font-medium text-[#C0C0C0]">
                      {message.role === 'user' ? 'You' : 'Assistant'}
                    </span>
                  </div>
                  <p className="whitespace-pre-wrap">{message.content}</p>
                </div>
              </div>
            </div>
          ))}
          {state.isLoading && (
            <div className="flex items-center justify-start mb-4">
              <div className="bg-[#1B1B1B] rounded-lg p-4">
                <Loader2 className="w-5 h-5 animate-spin text-[#C0C0C0]" />
              </div>
            </div>
          )}
          {state.error && (
            <div className="text-red-500 text-center mb-4">{state.error}</div>
          )}
          <div ref={messagesEndRef} />
        </div>

        <form onSubmit={handleSubmit} className="flex space-x-4">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type your message..."
            className="flex-1 rounded-lg bg-[#FFFFFF] text-[#2A3439] border-[#2A3439] shadow-sm focus:border-[#C0C0C0] focus:ring-[#C0C0C0] placeholder-[#2A3439]"
            disabled={state.isLoading}
          />
          <button
            type="submit"
            disabled={state.isLoading || !input.trim()}
            className="bg-[#2A3439] text-[#FFFFFF] px-4 py-2 rounded-lg hover:bg-[#1B1B1B] focus:outline-none focus:ring-2 focus:ring-[#C0C0C0] focus:ring-offset-2 focus:ring-offset-[#120F2D] disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Send className="w-5 h-5" />
          </button>
        </form>
      </main>
    </div>
  );
}

export default App;